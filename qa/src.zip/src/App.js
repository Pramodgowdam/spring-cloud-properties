import './App.css';
import Greet from './HelloWorld/GreetStateless';
import Greet1 from './HelloWorld/GreetStatefull';
import Hello from './HelloWorld/Hello';
import Message from './HelloWorld/Message';
import Counter from './State/Counter';
import FunctionClick from './eventHandling/FunctionClick';
import EventBind from './eventHandling/EventBind';
import Form from './Form/Form';
import LifeCycleA from './LifeCycle/LifeCycleA';
import PureComp from './components/PureComp';
import ParentComponent from './components/ParentComponent';
import RefsDemo from './Refs/RefsDemo';
import FRParentInput from './Refs/FRParentInput';
import ClickCounter from './hoa/ClickCounter';
import HOverCounter from './hoa/HOverCounter';
import HoverCounterTwo from './Render/HoverCounterTwo';
import ClickCounterTwo from './Render/ClickCounterTwo';
import User from './Render/User';
import ComponentA from './context/ComponentA';
import { UserProvider } from './context/UserContext';
import ClassCounter from './hooks/ClassCounter';
import HookCounter from './hooks/HookCounter';
import HookCounterTwo from './hooks/HookCounterTwo';
import HookCounterThree from './hooks/HookCounterThree';

function App() {
  return (
    <div className="App">
    
    <HookCounterThree/>
    
    
      
   
      {/*
          <HookCounterTwo/>

      <HookCounter/>
      <ClassCounter/>
      <UserProvider value='Pramod Maradirangaiah'>
      <ComponentA/>
    </UserProvider>
         <User name={(count, incrementCount) => <HoverCounterTwo count={count} incrementCount={incrementCount} /> }/>
      <User name={(count, incrementCount) => <ClickCounterTwo count={count} incrementCount={incrementCount} /> }/>
 
      <ClickCounterTwo/>
      <ClickCounter/>
      <HOverCounter/>
      <FRParentInput/>
      <RefsDemo/>
      <ParentComponent/>

      <LifeCycleA/>
      <Form/>

      <ParentComponent/>
      <EventBind/>
      <FunctionClick/>
      <Counter/>
      <Message/>
      <Greet name='Naveen'>
        <p>Sonu and Monu are his childrens</p>
        </Greet>
      <Greet name='Manjunatha'>
        <button>Click Me</button>
        </Greet>
      <Greet name='Pramod'/>

       
      <Greet1/> 
      <Hello/>*/}
    </div>
  );
}

export default App;
