import React, { Component } from 'react'

class EventBind extends Component {

    constructor(props) {
      super(props)
    
      this.state = {
         message: 'Hello'
      }
      this.clickHandler = this.clickHandler.bind(this); // Approach 3

    }
    // 1 2
    /* clickHandler (){
        this.setState({
            message: 'GoodBye!'
        })
    } */
    clickHandler = () =>{
        this.setState({
            message: 'GoodBye!'
        })
        //console.log(this.state.message);
    }
  render() {
    return (
        <div>
            <div>{this.state.message}</div>
            {/* <button onClick={this.clickHandler().bind(this)}> Click Me</button>  Approach 1 */}
            {/* <button onClick={() => this.clickHandler ()}> Click Me</button> Approach 2 */}
            {/* <button onClick={this.clickHandler}> Click Me</button> Approach 3 */}
            <button onClick={this.clickHandler}> Click Me</button> // Approach 4
        </div>
    );
  }
}

export default EventBind