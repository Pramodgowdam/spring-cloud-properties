import React, { Component } from 'react'
import PureComp from './PureComp'
import RegularComponent from './RegularComponent'

export class ParentComponent extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name: 'Pramod'
      }
    }
    componentDidMount(){
        setInterval(() => { 
            this.setState({
                name: 'Vishwas'
            })}, 1000)
    }
    render() {
        console.log('**************** Parent Component *****************')
        return (
            <div> 
                Parent Component
                <RegularComponent name={this.state.name} />
                <PureComp name={this.state.name} />
            </div>
        )
  }
}

export default ParentComponent