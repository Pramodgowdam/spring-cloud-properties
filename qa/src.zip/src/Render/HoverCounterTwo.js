import React, { Component } from 'react'

export class HoverCounterTwo extends Component {
    constructor(props) {
        super(props)
      
        this.state = {
           count: 0
        }
      }
      
      incrementCount = () =>{
          this.setState(previousState => {
              return {count: previousState.count+1}
          })
      }

    render() {
    return (
          <label onMouseOver={this.incrementCount}>Click {this.state.count} times</label>
    )
  }
}

export default HoverCounterTwo