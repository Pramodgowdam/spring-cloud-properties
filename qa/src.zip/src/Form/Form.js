import React, { Component } from 'react'

export class Form extends Component {
constructor(props) {
  super(props)

  this.state = {
     userName: '',
     comment: '',
     topic: 'vue'
  }
}

handleNameChange = (event) =>{
    this.setState({
        userName : event.target.value
    }, ()=> {console.log(this.state.userName)})
}

handleCommentChange = (event) =>{
    this.setState({
        comment: event.target.value
    }, ()=> {console.log(this.state.comment)})
}

handleTopicChange = (event) =>{
    this.setState({
        topic: event.target.value
    }, ()=> {console.log(this.state.topic)})
}
handleSubmit =(event) =>{
    alert(`${this.state.userName} ${this.state.comment} ${this.state.topic}`)
    event.preventDefault()
}
  render() {
    return (
      <form onSubmit={this.handleSubmit}>
          <div>
              <label>User name</label>
              <input type='text' value={this.state.userName} onChange={this.handleNameChange}/>
          </div>
          <div>
              <label>Comments</label>
              <textarea value={this.state.comment} onChange={this.handleCommentChange
            }/>
          </div>
          <div>
              <label>Topic</label>
              <select value={this.state.topic} onChange={this.handleTopicChange}>
                  <option value='Angular'>Angular</option>
                  <option value='React'>React</option>
                  <option value='vue'>vue</option>
                </select> 
          </div>
          <button type='submit' >Submit</button>
      </form>
    )
  }
}

export default Form