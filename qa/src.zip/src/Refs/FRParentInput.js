import React, { Component } from 'react'
import FRInput from './FRInput'

export class FRParentInput extends Component {
    constructor(props) {
        super(props)
        this.frRef = React.createRef()
    }
    clickHandler = () =>{
        this.frRef.current.value='Pramod Maradirangaiah'
    }
    
      render() {
        return (
         <div>
             <FRInput ref={this.frRef}/>
            <div>
                <button onClick={this.clickHandler}>Focus Input</button>                
            </div>
            
          </div>
        )
      }
    }

export default FRParentInput