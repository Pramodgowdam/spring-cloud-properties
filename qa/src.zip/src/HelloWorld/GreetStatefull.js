import React, { Component } from "react";


class Greet1 extends Component{
    constructor(props) {
      super(props)
    }

    render(){
        return(
            <h1>Greet Pramod in GreetStateless</h1>
        );
    }
}

export default Greet1;