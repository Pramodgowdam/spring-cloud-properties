import React from "react";

const Hello = () =>{
    return (
        <div>
            <h1>Hello Pramod</h1>
        </div>
    )
}

export default Hello;