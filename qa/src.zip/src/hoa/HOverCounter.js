import React, { Component } from 'react'
import UpdateComponent from './withCounter'

export class HOverCounter extends Component {
/* constructor(props) {
  super(props)

  this.state = {
     count: 0
  }
}

handleMouseOver = () =>{
    this.setState(previousState =>{
        return {count: previousState.count + 1}
    })
}*/

  render() {
    return (
      <label onMouseOver={this.props.incrementCount}>HOvered {this.props.count} time</label>
    )
  }
} 

export default UpdateComponent(HOverCounter)