import React, { useState } from 'react'

function HookCounterTwo() {
    const [count, setCount] = useState(0)

    const increment =() =>{
        setCount(previousCount =>  previousCount+1
        )
    }
    const decrement = () =>{
        setCount(previousCount =>  previousCount-1
        )
    }
  return (
    <div>
        Count: {count}
        <button onClick={increment}>Increment</button>
        <button onClick={decrement}>Decrement</button>
        <button onClick={()=> setCount(0)}>Reset</button>
    </div>
  )
}

export default HookCounterTwo
