import React, { useState } from 'react'

function HookCounterThree() {
    const [person, setPerson] = useState({firstName: '', lastName: ''})
  return (
    <form>
        <input type='text' value={person.firstName} onChange={ e => setPerson({... person, firstName: e.target.value})}/>
        <input type='text' value={person.lastName} onChange={ e => setPerson({... person, lastName: e.target.value})}/>
        <h2>First Name: {person.firstName}</h2>
        <h2>First Name: {person.lastName}</h2>
    </form>
  )
}

export default HookCounterThree